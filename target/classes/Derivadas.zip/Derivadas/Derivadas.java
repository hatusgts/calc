/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Derivadas;
import java.util.concurrent.TimeUnit;
import org.matheclipse.core.eval.ExprEvaluator;
/**
 *
 * @author danie
 */
public class Derivadas {
    public String calculaDerivada(String expressao, String variavel){
        ExprEvaluator derivada = new ExprEvaluator();
        String entrada = "D(" + expressao + ", " + variavel + ")";
        return derivada.evaluate(entrada).toString();
    }
    
    public String calculaDerivadaSegunda(String expressao, String variavel){
        ExprEvaluator segundaOrdem = new ExprEvaluator();
        String entrada = "D(" + expressao + ", " +"{" +variavel + ", 2})";
        return segundaOrdem.evaluate(entrada).toString();
    }
}
