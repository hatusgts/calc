/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Derivadas;
import java.util.Scanner;
/**
 *
 * @author danie
 */
public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        Derivadas deriva = new Derivadas();
        
        System.out.println("Digite a expressao: ");
        String expressao = scanner.nextLine();
        
        System.out.println("Digite a variavel: ");
        String variavel = scanner.nextLine();
        
        System.out.println(deriva.calculaDerivadaSegunda(expressao, variavel));
    }
}
